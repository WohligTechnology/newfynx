
    <!-- Body starts -->
    <div class="row dash-row">
<!--
        <div class="col m3">
            <div class="card red darken-1 mar-left-30 ">
                <div class="card-content white-text text-center">
                    <i class="large mdi-action-favorite-outline block"></i>
                    <span class="card-title">478 Sales</span>
                </div>
            </div>
        </div>
-->


        <div class="col l3 m6 s12">
            <div class="card red darken-1">
                <div class="card-content white-text text-center">
                    <i class="large mdi-action-account-child block"></i>
<!--                    <span class="card-title"><?php echo $usercount;?> Users</span>-->
                </div>
            </div>
        </div>
<!--
        <div class="col m3">
            <div class="card pink darken-1 mar-left-30 ">
                <div class="card-content white-text text-center">
                    <i class="large mdi-action-favorite-outline block"></i>
                    <span class="card-title">478 Sales</span>
                </div>
            </div>

        </div>

        <div class="col m3">
            <div class="card navy-blue darken-1 mar-left-30 ">
                <div class="card-content white-text text-center">
                    <i class="large mdi-action-favorite-outline block"></i>
                    <span class="card-title">478 Sales</span>
                </div>
            </div>
        </div>
-->
    </div>

    <!-- Body Ends -->